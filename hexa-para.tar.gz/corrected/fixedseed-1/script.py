import os, sys, time
root = os.path.dirname(__file__)
sys.path.append(root)

import Auto3D
from Auto3D.auto3D import options, main
from Auto3D.ASE.geometry import opt_geometry

#from rdkit import Chem             # needed if .smi file is used as input
#from rdkit.Chem import AllChem     # needed if .smi file is used as input

#Always ensure that you have the latest version
print(Auto3D.__version__)


# This following section is needed if .smi file is used as input. Comment out if you are using .sdf
#mol = Chem.MolFromSmiles("CCO")
#mol = Chem.AddHs(mol)
#AllChem.EmbedMolecule(mol, AllChem.ETKDG())
#AllChem.UFFOptimizeMolecule(mol)

#w = Chem.SDWriter("ethanol_init.sdf")
#w.write(mol)
#w.close()


source_dir_hexa = "/groups/bsavoie2/shaldar09/Auto3D/glucose-binder/docking/rdkit-dock/peptides/xy/parallel/hexa/corrected/fixedseed-1"
dir_list = [d for d in os.listdir(source_dir_hexa) if os.path.isdir(os.path.join(source_dir_hexa,d))]

if __name__ == "__main__":
    # Start total timer
    total_start = time.time()
    print(f"Starting batch optimization of {len(dir_list)} files...")

    for i, directory in enumerate(dir_list):
        base = os.path.basename(directory)
        print("base = ", base)
        if not os.path.exists(base):
            os.makedirs(base)

        # Copy file and move into directory
        os.system(f"cp {source_dir_hexa}/{base}/{base}-glu_opt.mol {base}/")

        # Start individual timer
        indiv_start = time.time()

        path = os.path.join(root, f'{base}/{base}-glu_opt.mol')  # Specify the path to your input (sdf) file here
        print(f"Optimizing {base}... [{i+1}/{len(dir_list)}]")

        try:
            optimized = opt_geometry(path, model_name="AIMNET", opt_tol=0.005, opt_steps=20000)

            # End individual timer
            indiv_end = time.time()
            duration = indiv_end - indiv_start
            print(f"DONE: {base} | Time: {duration:.2f} seconds")

        except Exception as e:
            print(f"FAILED: {base} | Error: {e}")

    # End total timer
    total_end = time.time()
    total_duration = total_end - total_start

    print("\n" + "="*30)
    print(f"BATCH COMPLETE")
    print(f"Total time elapsed: {total_duration/60:.2f} minutes")
    print("="*30)
