#!/usr/bin/env python3
"""
Usage:
    python get_energy.py

Requirements:
    - RDKit
"""

import os
import csv
from rdkit import Chem

root = os.path.dirname(os.path.abspath(__file__))
out_csv = os.path.join(root, "Etot_opt.csv")

job_dirs = sorted([i for i in os.listdir(root) if os.path.isdir(os.path.join(root, i))]) # The sorted function will always return the subfolders in csv in a specific order

rows = []

for i, job_dir in enumerate(job_dirs):
    sdf_file = os.path.join(root, (job_dir+'/'+str(job_dir)+"-glu_opt_userNNP_opt.sdf"))
    mol_supplier = Chem.SDMolSupplier(sdf_file)    # "mol_supplier" is not a rdkit "mol" object yet. It's an iterator. An sdf file can contain multiple molecules in it. So at this step we are creating just an iterator that iterates over all the molecules in the sdf file
   

    mol = next((m for m in mol_supplier if m is not None), None)   # Get each "mol" object from the mol_supplier
    E = float(mol.GetProp("E_tot"))
    fmax = float(mol.GetProp("fmax"))
    status = mol.GetProp("Converged")
    rows.append([job_dir, E, fmax, status])

with open(out_csv, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["job_dir", "E_tot", "fmax", "Convergence"])
    w.writerows(rows)


print("Wrote:", out_csv)
