import os
from pyPept.sequence import Sequence, correct_pdb_atoms
from pyPept.molecule import Molecule
from rdkit import Chem
from rdkit.Chem import AllChem

# ---------- helpers ----------
def get_resnum(atom):
    info = atom.GetPDBResidueInfo()
    return info.GetResidueNumber() if info else None

def get_atomname(atom):
    info = atom.GetPDBResidueInfo()
    return info.GetName().strip() if info else ""

def find_cys_sg_indices(romol, expected_res=(1,4)):
    """Return a dict {resnum: sg_idx} for the cysteine SG atoms in this molecule."""
    sg_by_res = {}
    for a in romol.GetAtoms():
        if a.GetAtomicNum() != 16:  # sulfur
            continue
        resnum = get_resnum(a)
        aname  = get_atomname(a)
        if resnum in expected_res and ((aname.upper() == "SG") or any(n.GetAtomicNum()==6 for n in a.GetNeighbors())):
            sg_by_res[resnum] = a.GetIdx()
    missing = [r for r in expected_res if r not in sg_by_res]
    if missing:
        raise RuntimeError(f"Missing SG atoms for residues {missing}")
    return sg_by_res

def remove_thiol_Hs(romol, s_indices):
    em = Chem.EditableMol(romol)
    to_del = []
    for s_idx in s_indices:
        s_atom = romol.GetAtomWithIdx(s_idx)
        for nbr in s_atom.GetNeighbors():
            if nbr.GetAtomicNum() == 1:
                to_del.append(nbr.GetIdx())
    for idx in sorted(set(to_del), reverse=True):
        em.RemoveAtom(idx)
    romol = em.GetMol()
    Chem.SanitizeMol(romol)
    return romol

#######################################
# Create the library for 20 amino acids
#######################################

amino_acids = ["A", "G", "I", "L", "P", "V", "F", "W", "Y", "D", "E", "R", "H", "K", "S", "T", "C", "M", "N", "Q"]

count = 0

# Define the cyclic pyranose glucose outside the loop for efficiency.
# This SMILES corresponds to beta-D-glucopyranose. 
# Feel free to replace it if you prefer alpha-D-glucose or a non-stereospecific string.
#glucose_smiles = "O[C@@H]1[C@@H](O)[C@H](O)[C@@H](CO)O[C@H]1O"
#glucose_mol = Chem.MolFromSmiles(glucose_smiles)

##############################################
# ---------- 1) Generate all 400 possible unique monomers
##############################################
monomer_list = []
for aa1 in amino_acids:
    for aa2 in amino_acids:
        monomer_list.append(f"C-{aa1}-{aa2}-C")

########################################################
# ---------- 2) Pair them (Homo-dimers and Hetero-dimers)
# This loop structure identifies the 80,200 unique pairs
########################################################
for i in range(len(monomer_list)):
    for j in range(i, len(monomer_list)):
        biln_tetrapep_1 = monomer_list[i]
        biln_tetrapep_2 = monomer_list[j]

        seqA = correct_pdb_atoms(Sequence(biln_tetrapep_1))
        seqB = correct_pdb_atoms(Sequence(biln_tetrapep_2))

        molA = Molecule(seqA); romolA = molA.get_molecule(fmt='ROMol')
        molB = Molecule(seqB); romolB = molB.get_molecule(fmt='ROMol')

        #####################################################################################
        # ---------- 3) find SG atoms in each (residues 1 and 4) & remove thiol Hs ----------
        #####################################################################################
        sgA = find_cys_sg_indices(romolA, expected_res=(1,4))
        sgB = find_cys_sg_indices(romolB, expected_res=(1,4))

        romolA = remove_thiol_Hs(romolA, s_indices=list(sgA.values()))
        romolB = remove_thiol_Hs(romolB, s_indices=list(sgB.values()))

        # After deleting atoms, re-find S indices by residue number (in case indices shifted)
        sgA = find_cys_sg_indices(romolA, expected_res=(1,4))
        sgB = find_cys_sg_indices(romolB, expected_res=(1,4))

        ##################################################################
        # ---------- 4) combine molecules WITHOUT peptide bonds ----------
        ##################################################################
        combo = Chem.CombineMols(romolA, romolB)
        em = Chem.EditableMol(combo)

        offsetB = romolA.GetNumAtoms()
        # Map SG indices from B with offset after combining
        sgB_off = {res: (idx + offsetB) for res, idx in sgB.items()}

        #############################################################################
        # ---------- 5) add two disulfide bonds ACROSS the two tetrapeptides ----------
        #############################################################################
        # Parallel linking: Cys1(A)–Cys1(B) and Cys4(A)–Cys4(B)
        em.AddBond(sgA[1], sgB_off[1], order=Chem.BondType.SINGLE)
        em.AddBond(sgA[4], sgB_off[4], order=Chem.BondType.SINGLE)

#        # Antiparallel linking: Cys1(A)–Cys4(B) and Cys4(A)–Cys1(B)
#        em.AddBond(sgA[1], sgB_off[4], order=Chem.BondType.SINGLE)
#        em.AddBond(sgA[4], sgB_off[1], order=Chem.BondType.SINGLE)

        romol = em.GetMol()
        Chem.SanitizeMol(romol)

        ####################################################################
        # ---------- 6) Add Glucose and Convert Composite to SMILES -------
        ####################################################################
        # Non-covalently combine the host macrocycle and the guest glucose
#        composite_mol = Chem.CombineMols(romol, glucose_mol)
        
        # RDKit will output a canonical SMILES representing the complex (separated by a dot)
        host_smiles = Chem.MolToSmiles(romol)

        ####################################################################
        # ---------- 7) write files ----------
        ####################################################################
        # Create a directory name for each first monomer (removing hyphens for simplicity)
        dir_name = monomer_list[i].replace("-", "")
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)

        # Extract the clean molecule name/ID (e.g., CEHC_CNTC)
        mol_id = f"{monomer_list[i].replace('-', '')}_{monomer_list[j].replace('-', '')}"
        file_name = f"{mol_id}.smi"
        full_path = os.path.join(dir_name, file_name)

        try:
            with open(full_path, "w") as f:
                # FIX: Auto3D needs the SMILES and the Molecule ID separated by a tab
                f.write(f"{host_smiles}\t{mol_id}\n")
            print(f"Wrote {full_path}")
            count += 1
        except Exception as e:
            print(f"Failed to write {file_name}: {e}")

print(f"Total {count} composite host-guest SMILES structures are generated")
